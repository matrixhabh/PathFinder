import { NextResponse } from 'next/server'
import { demoPathResponse, type PathResponse } from '@/lib/pathfinder-data'

export async function POST(request: Request) {
  let context: unknown = null
  try { context = await request.json() } catch { context = null }
  void context
  const response: PathResponse = { ...demoPathResponse(), fallback: !process.env.PATHFINDER_AI_ENDPOINT }
  if (process.env.PATHFINDER_AI_ENDPOINT) {
    try {
      const upstream = await fetch(process.env.PATHFINDER_AI_ENDPOINT, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(context) })
      if (upstream.ok) return NextResponse.json(await upstream.json())
    } catch { /* Keep the local demo path available. */ }
  }
  return NextResponse.json(response)
}
